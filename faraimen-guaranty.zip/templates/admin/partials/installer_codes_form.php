<form action="" method="post">
    <p>
        <label for="installer_codes">کدها را با اینتر از هم جدا کنید. (هر کد را در یک خط بنویسید.)</label>
    </p>
    <textarea name="installer_codes" id="installer_codes" cols="30" rows="10"></textarea>
    <div>
        <input type="submit" name="installers_code_data" class="button button-primary" value="افزودن">
    </div>
</form>