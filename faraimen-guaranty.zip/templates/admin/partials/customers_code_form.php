<form action="" method="post">
	<p>
		<label for="customer_codes">کدها را با اینتر از هم جدا کنید. (هر کد را در یک خط بنویسید.)</label>
	</p>
	<textarea name="customer_codes" id="customer_codes" cols="30" rows="10"></textarea>
    <div>
        <input type="submit" name="customers_code_data" class="button button-primary" value="افزودن">
    </div>
</form>